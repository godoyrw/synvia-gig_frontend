// src/plugins/session-expiration.js
import { useAuthStore } from '@/stores/auth';

export function sessionExpirationPlugin() {
    let interval = null;

    return ({ store }) => {

        // Só ativa no auth store
        if (store.$id !== 'auth') return;

        // Evita múltiplos intervalos
        if (interval) clearInterval(interval);

        // Watchdog global
        interval = setInterval(() => {
            const auth = useAuthStore();

            if (auth.isExpired) {
                console.warn("⏳ Sessão expirada!");
                auth.logout(true);
            }
        }, 5000); // checa a cada 5s
    };
}
