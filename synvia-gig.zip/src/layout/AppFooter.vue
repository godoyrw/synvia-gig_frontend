<script setup></script>

<template>
    <div class="layout-footer">
        <span class="text-primary font-bold">SYNVIA™ | The Intelligent Infrastructure for Health Management</span>
    </div>
</template>
