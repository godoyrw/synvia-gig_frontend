// src/stores/auth.js
import router from '@/router';
import { login as mockLogin } from '@/services/auth';
import { defineStore } from 'pinia';

export const useAuthStore = defineStore('auth', {
  state: () => ({
    token: sessionStorage.getItem('auth_token') || null,
    user: JSON.parse(sessionStorage.getItem('auth_user') || 'null'),
    expiresAt: Number(sessionStorage.getItem('auth_expires')) || null
  }),

  getters: {
    // válido enquanto houver token E (não tiver expiresAt ou não expirou)
    isAuthenticated: (s) =>
      !!s.token && (!s.expiresAt || Date.now() < s.expiresAt),

    // expirado = tem expiresAt e já passou
    isExpired: (s) =>
      !!s.expiresAt && Date.now() >= s.expiresAt
  },

  actions: {
    /**
     * Login usando o mock
     */
    async loginWithCredentials(username, password, durationMinutes = 1) {
      const result = await mockLogin(username, password);

      if (!result.ok) {
        throw new Error(result.message || 'Falha na autenticação');
      }

      // define os minutos de sessão
      const expiresAt = Date.now() + durationMinutes * 60 * 1000;

      this.token = result.token;
      this.user = result.user;
      this.expiresAt = expiresAt;

      sessionStorage.setItem('auth_token', this.token);
      sessionStorage.setItem('auth_user', JSON.stringify(this.user));
      sessionStorage.setItem('auth_expires', expiresAt);
    },

    /**
     * Logout clássico + logout por expiração
     */
    logout(expired = false) {
      this.token = null;
      this.user = null;
      this.expiresAt = null;

      sessionStorage.removeItem('auth_token');
      sessionStorage.removeItem('auth_user');
      sessionStorage.removeItem('auth_expires');

      // garante que logout não corre antes do router estar pronto
      setTimeout(() => {
        if (expired) {
          router.replace('/auth/login?expired=true');
        } else {
          router.replace('/auth/login');
        }
      }, 0);
    },

    /**
     * Verifica expiração a qualquer momento
     */
    checkExpiration() {
      if (this.isExpired) {
        this.logout(true);
      }
    }
  }
});
