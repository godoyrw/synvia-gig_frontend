// src/main.js
import { createPinia } from 'pinia';
import { createApp } from 'vue';

import App from './App.vue';
import router from './router';

import { sessionExpirationPlugin } from '@/plugins/session-expiration';

import { $t } from '@primeuix/themes';
import Aura from '@primeuix/themes/aura';
import PrimeVue from 'primevue/config';
import ConfirmationService from 'primevue/confirmationservice';
import ToastService from 'primevue/toastservice';

import '@/assets/styles.scss';
import '@/assets/tailwind.css';

document.documentElement.classList.add('app-dark');

const app = createApp(App);

const pinia = createPinia();
pinia.use(sessionExpirationPlugin);
app.use(pinia);

app.use(router);

app.use(PrimeVue, {
    theme: {
        preset: Aura,
        options: { darkModeSelector: '.app-dark' }
    }
});

// ----------------------
// TEMA SYNVIA
// ----------------------
$t()
    .preset(Aura)
    .preset({
        semantic: {
            primary: {
                50: '#E6FBFB',
                100: '#C0F5F6',
                200: '#8AEDEF',
                300: '#55E3E6',
                400: '#31DBDF',
                500: '#27DDDF',
                600: '#1FB6B8',
                700: '#199093',
                800: '#126A6E',
                900: '#0C4C50',
                950: '#072E31'
            },
            secundary: {
                50: '#F9FAFB',  // quase branco
                100: '#F3F4F6',  // fundo leve de página
                200: '#E5E7EB',  // bordas sutis
                300: '#D1D5DB',  // divisores, campos desativados
                400: '#9CA3AF',  // texto secundário
                500: '#6B7280',  // texto padrão leve
                600: '#4B5563',  // texto primário em light mode
                700: '#374151',  // texto escuro
                800: '#1F2937',  // background dark
                900: '#111827',  // quase preto
                950: '#0B0F16'   // fundo dark absoluto
            }

        }
    }
    })
    .use({ useDefaultOptions: true });

app.use(ToastService);
app.use(ConfirmationService);

app.mount('#app');
