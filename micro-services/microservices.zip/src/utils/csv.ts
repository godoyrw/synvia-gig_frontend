import { parse } from 'csv-parse/sync';
import type { ImportRowError } from '../types/import.js';

export interface CsvAnalysis {
  totalRows: number;
  importedRows: number;
  errorRows: number;
  errors: ImportRowError[];
  header: string[];
  missingColumns: string[];
}

export interface AnalyzeCsvOptions {
  requiredColumns?: string[];
  numericColumns?: string[];
  dateColumns?: string[];
  maxErrors?: number;
}

const DEFAULT_OPTIONS: Required<AnalyzeCsvOptions> = {
  requiredColumns: [],
  numericColumns: [],
  dateColumns: [],
  maxErrors: 25
};

const escapeForRegExp = (value: string) => value.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&');

const detectDelimiter = (buffer: Buffer, fallback = ','): string => {
  const sample = buffer.toString('utf8', 0, Math.min(buffer.length, 1024));
  const firstLine = sample.split(/\r?\n/).find((line) => line.trim().length);
  if (!firstLine) {
    return fallback;
  }

  const candidates: Array<{ delimiter: string; count: number }> = [',', ';', '\t', '|'].map((delimiter) => {
    const regex = new RegExp(escapeForRegExp(delimiter), 'g');
    const matches = firstLine.match(regex);
    return {
      delimiter,
      count: matches ? matches.length : 0
    };
  });

  const best = candidates.reduce(
    (prev, current) => (current.count > prev.count ? current : prev),
    { delimiter: fallback, count: 0 }
  );

  return best.count > 0 ? best.delimiter : fallback;
};

const isISODate = (value: string) => /^\d{4}-\d{2}-\d{2}$/.test(value);

const pushError = (errors: ImportRowError[], error: ImportRowError, limit: number) => {
  if (errors.length < limit) {
    errors.push(error);
  }
};

/**
 * Traduz mensagens comuns do csv-parse para PT-BR amigável.
 */
const translateCsvParseError = (msg: string): string => {
  const openingQuote = msg.match(/^Invalid Opening Quote: a quote is found on field (\d+) at line (\d+), value is "(.*)" \((.*)\)/);
  if (openingQuote) {
    const [, field, line, value, extra] = openingQuote;
    return `Aspa inicial inválida: foi encontrada uma aspa inesperada no campo ${field} na linha ${line}; valor "${value}" (${extra}).`;
  }
  if (/^Invalid Closing Quote:/.test(msg)) {
    return 'Aspa de fechamento inválida: verifique se todas as aspas estão balanceadas.';
  }
  if (/^Quoted field not terminated/.test(msg)) {
    return 'Campo entre aspas não foi finalizado corretamente.';
  }
  if (/^Invalid Record Length:/.test(msg)) {
    return 'Comprimento de registro inválido: número de colunas inconsistente.';
  }
  return `Erro ao analisar CSV: ${msg}`;
};

export const analyzeCsvBuffer = (buffer: Buffer, options: AnalyzeCsvOptions = {}): CsvAnalysis => {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  let rows: string[][] = [];
  try {
    const delimiter = detectDelimiter(buffer);
    rows = parse(buffer, {
      skip_empty_lines: true,
      relax_column_count: true,
      trim: true,
      delimiter
    }) as string[][];
  } catch (parseErr) {
    const rawMessage = parseErr instanceof Error ? parseErr.message : 'Falha desconhecida ao ler CSV.';
    return {
      totalRows: 0,
      importedRows: 0,
      errorRows: 0,
      header: [],
      missingColumns: [],
      errors: [
        {
          line: 0,
          reason: translateCsvParseError(rawMessage),
          code: 'CSV_PARSE_ERROR',
          details: { originalMessage: rawMessage }
        }
      ]
    };
  }

  if (!rows.length) {
    return { totalRows: 0, importedRows: 0, errorRows: 0, errors: [], header: [], missingColumns: [] };
  }

  const [headerRow, ...dataRows] = rows;
  const normalizedHeader = headerRow.map((col) => col?.trim?.().toLowerCase?.() ?? '');
  const header = headerRow.map((col) => col?.trim?.() ?? '');

  const headerMap = new Map<string, number>();
  normalizedHeader.forEach((value, index) => {
    if (!headerMap.has(value)) {
      headerMap.set(value, index);
    }
  });

  const missingColumns = opts.requiredColumns.filter((required) => !headerMap.has(required));

  const errors: ImportRowError[] = [];
  let errorRows = 0;

  if (missingColumns.length) {
    pushError(
      errors,
      {
        line: 1,
        reason: `Cabeçalho inválido. Colunas ausentes: ${missingColumns.join(', ')}.`,
        code: 'INVALID_HEADER',
        details: {
          missingColumns,
          expectedColumns: opts.requiredColumns,
          receivedColumns: header
        }
      },
      opts.maxErrors
    );
  }

  dataRows.forEach((row, index) => {
    const lineNumber = index + 2;
    let rowHasError = false;

    if (row.length !== header.length) {
      rowHasError = true;
      pushError(
        errors,
        {
          line: lineNumber,
          reason: 'Estrutura da linha não coincide com o cabeçalho.',
          code: 'ROW_PARSE_FAILURE',
          details: {
            expectedColumns: header.length,
            receivedColumns: row.length,
            raw_line_preview: row.join(',')
          }
        },
        opts.maxErrors
      );
    }

    opts.requiredColumns.forEach((column) => {
      const columnIndex = headerMap.get(column);
      if (columnIndex === undefined) {
        return;
      }

      const value = row[columnIndex]?.trim?.();
      if (!value) {
        rowHasError = true;
        pushError(
          errors,
          {
            line: lineNumber,
            reason: `Coluna obrigatória "${column}" vazia.`,
            code: 'MISSING_REQUIRED_FIELD',
            details: { column }
          },
          opts.maxErrors
        );
      }
    });

    opts.dateColumns.forEach((column) => {
      const columnIndex = headerMap.get(column);
      if (columnIndex === undefined) {
        return;
      }

      const value = row[columnIndex]?.trim?.();
      if (value && !isISODate(value)) {
        rowHasError = true;
        pushError(
          errors,
          {
            line: lineNumber,
            reason: `Formato de data inválido em "${column}".`,
            code: 'INVALID_DATE_FORMAT',
            details: {
              column,
              invalidValue: value,
              expectedFormat: 'YYYY-MM-DD'
            }
          },
          opts.maxErrors
        );
      }
    });

    opts.numericColumns.forEach((column) => {
      const columnIndex = headerMap.get(column);
      if (columnIndex === undefined) {
        return;
      }

      const value = row[columnIndex]?.trim?.();
      if (value && Number.isNaN(Number(value))) {
        rowHasError = true;
        pushError(
          errors,
          {
            line: lineNumber,
            reason: `Valor numérico inválido em "${column}".`,
            code: 'INVALID_NUMBER',
            details: {
              column,
              invalidValue: value
            }
          },
          opts.maxErrors
        );
      }
    });

    if (rowHasError) {
      errorRows += 1;
    }
  });

  const totalRows = dataRows.length;
  const importedRows = Math.max(totalRows - errorRows, 0);

  return {
    totalRows,
    importedRows,
    errorRows,
    errors,
    header,
    missingColumns
  };
};
