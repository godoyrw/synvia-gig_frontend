# SYNVIA™ | The Intelligent Infrastructure for Health Management

## Getting Started NPM

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Getting Started PNPM

```bash
# Install dependencies
pnpm install

# Start development server
pnpm dev

# Build for production
pnpm build
```
