// Barrel de composables - atualmente vazio porque `useDialog` foi substituído por uma store Pinia.
// Adicione exportações aqui quando criar novos composables.

export { useActivityTracker } from './useActivityTracker';

