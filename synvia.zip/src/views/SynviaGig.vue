<script setup>
import synviaGigLogo from '@/assets/images/logos/synvia_gig_positivo.png';
</script>

<template>
    <div class="card">
        <div class="font-semibold text-xl mb-4">
            <img :src="synviaGigLogo" alt="Logo" class="w-60 mt-0" />
        </div>
    </div>
</template>
